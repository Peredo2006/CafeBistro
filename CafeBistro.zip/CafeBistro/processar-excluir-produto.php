<?php
require_once "conexao.php";

// ...
$id = $_GET["id"];
$sql = "DELETE FROM produtos WHERE id = '$id'";

    if ($conn->query($sql) === TRUE) {
        header("Location: excluir-produto-sucesso.php");
        exit();
    } else {
        header("Location: excluir-produto.php?erro=2");
        exit();
    }
    $conn->close();

?>